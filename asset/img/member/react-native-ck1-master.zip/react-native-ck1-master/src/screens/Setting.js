import React from 'react'
import { View, Text } from 'react-native'

export default function Setting() {
  return (
    <View>
      <Text>Setting</Text>
    </View>
  )
}
