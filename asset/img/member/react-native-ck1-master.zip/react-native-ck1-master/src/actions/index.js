import person from "./personAction";

export const ActionCreators = Object.assign({
  person
});
