flex: 1 => full
cha:
flexDirection
justifyContent
alignItems
alignContent
con:
alignSelf

 position: 'absolute',


padding: từ cha đến con
margin: con => cha


=====
```
git clone https://github.com/hungdev/react-native-ck1.git
cd folder cua ban
npm i

git pull
```